Xano M1 native review bundle
Base repository: Gopi-git-bit/Xano-Synthentic-Prototype
Base commit: 31fac05763a762680324d014f0b1dcb32955ea84
Branch reference: codex/xano-backend-review

This is a review patch, not a deployment. No repository push or Xano import occurred.
The changes.patch file was checked against a fresh copy of the exact base snapshot.

Apply in a clean checkout of that commit:
  git apply --check changes.patch
  git apply changes.patch

The files/ folder also contains each changed/new file.
Read backend/milestone1/README.md for use, prerequisites and limits.
Credentials are not included. Set XANO_METADATA_TOKEN through a secret facility.

Native dry-run accepted eight candidates. The adapter's authenticated read-only
preflight is blocked. All 31 hosted behavior cases and full rollback proofs remain
unexecuted. No result in this bundle clears staging readiness.
